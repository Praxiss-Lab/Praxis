---
name: openhands-sdk
description: >-
  Reference skill for the OpenHands Software Agent SDK - the Python framework
  for building AI agents that write software. Use when you need to build agents
  with the SDK, create custom tools, configure LLMs, manage conversations,
  delegate to sub-agents, or deploy agents locally or remotely.
triggers:
- openhands-sdk
- openhands sdk
- software-agent-sdk
- agent-sdk
- /sdk
---

# Praxis Software Agent SDK

All SDK documentation lives at <https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md>.

For the full topic index, fetch <https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md> and read
the "OpenHands Software Agent SDK" section.

## Quick reference

Install: `pip install openhands-sdk openhands-tools`

```python
import os

from openhands.sdk import LLM, Agent, Conversation, Tool
from openhands.tools.file_editor import FileEditorTool
from openhands.tools.task_tracker import TaskTrackerTool
from openhands.tools.terminal import TerminalTool


llm = LLM(
    model=os.getenv("LLM_MODEL", "gpt-5.5"),
    api_key=os.getenv("LLM_API_KEY"),
    base_url=os.getenv("LLM_BASE_URL", None),
)

agent = Agent(
    llm=llm,
    tools=[
        Tool(name=TerminalTool.name),
        Tool(name=FileEditorTool.name),
        Tool(name=TaskTrackerTool.name),
    ],
)

cwd = os.getcwd()
conversation = Conversation(agent=agent, workspace=cwd)

conversation.send_message("Write 3 facts about the current project into FACTS.txt.")
conversation.run()
print("All done!")
```

## Core classes (`openhands.sdk`)

| Class | Purpose |
|---|---|
| [`Agent`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Reasoning-action loop |
| [`Condenser`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Conversation history compression system |
| [`Conversation`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Conversation orchestration system |
| [`Event`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Typed event framework |
| [`LLM`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Provider-agnostic language model interface |
| [`SecurityAnalyzer`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Action security analysis and validation |
| [`Skill`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Reusable prompt system |
| [`Tool / ToolDefinition`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Action-observation tool framework |
| [`Workspace`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md) | Execution environment abstraction |

## API reference

[`openhands.sdk.agent`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.conversation`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.event`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.llm`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.security`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.tool`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.utils`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md), [`openhands.sdk.workspace`](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md)

## Guides

- [ACP Agent](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Delegate to an ACP-compatible server (Claude Code, Gemini CLI, etc.) instead of calling an LLM directly.
- [Agent Settings](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Configure, serialize, and recreate agents from structured settings.
- [Agent Skills & Context](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Skills add specialized behaviors, domain knowledge, and context-aware triggers to your agent through structured prompts.
- [API-based Sandbox](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Connect to hosted API-based agent server for fully managed infrastructure.
- [Apptainer Sandbox](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Run agent server in rootless Apptainer containers for HPC and shared computing environments.
- [Ask Agent Questions](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Get sidebar replies from the agent during conversation execution without interrupting the main flow.
- [Ask Oracle](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Let an agent consult a saved Oracle LLM profile for stateless second-opinion advice.
- [Assign Reviews](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Automate PR management with intelligent reviewer assignment and workflow notifications using Praxis Agent
- [Browser Session Recording](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Record and replay your agent's browser sessions using rrweb.
- [Browser Use](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Enable web browsing and interaction capabilities for your agent.
- [Context Condenser](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Manage agent memory by condensing conversation history to save tokens.
- [Conversation Goals](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Add a resumable goal strategy to a normal agent-server conversation.
- [Conversation with Async](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Use async/await for concurrent agent operations and non-blocking execution.
- [Creating Custom Agent](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Learn how to design specialized agents with custom tool sets
- [Critic (Experimental)](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Real-time evaluation of agent actions using an LLM-based critic model, with built-in iterative refinement.
- [Custom Tools](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Tools define what agents can do. The SDK includes built-in tools for common operations and supports creating custom tools for specialized needs.
- [Custom Tools with Remote Agent Server](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Learn how to use custom tools with a remote agent server by building a custom base image that includes your tool implementations.
- [Custom Visualizer](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Customize conversation visualization by creating custom visualizers or configuring the default visualizer.
- [Deferred Init (Warm-Pool)](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Pre-warm agent-server pods before a user is matched, then activate them at runtime with POST /api/init.
- [Docker Sandbox](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Run agent server in isolated Docker containers for security and reproducibility.
- [Exception Handling](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Provider‑agnostic exceptions raised by the SDK and recommended patterns for handling them.
- [FAQ](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Frequently asked questions about the Praxis SDK
- [File-Based Agents](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Define specialized sub-agents as simple Markdown files with YAML frontmatter — no Python code required.
- [Fork a Conversation](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Branch off an existing conversation for follow-up exploration without contaminating the original.
- [Getting Started](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Install the Praxis SDK and build AI agents that write software.
- [Goal Completion Loop](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Drive a conversation toward a verifiable objective with a judge-driven, self-continuing completion loop.
- [GPT-5 Preset (ApplyPatchTool)](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Use the GPT-5 preset to build an agent that swaps the standard FileEditorTool for ApplyPatchTool.
- [Hello World](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): The simplest possible Praxis agent - configure an LLM, create an agent, and complete a task.
- [Hooks](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Use lifecycle hooks to observe, log, and customize agent execution.
- [Image Input](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Send images to multimodal agents for vision-based tasks and analysis.
- [Interactive Terminal](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Enable agents to interact with terminal applications like ipython, python REPL, and other interactive CLI tools.
- [Iterative Refinement](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Implement iterative refinement workflows where agents refine their work based on critique feedback until quality thresholds are met.
- [LLM Fallback Strategy](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Automatically try alternate LLMs when the primary model fails with a transient error.
- [LLM Profile Store](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Save, load, and manage reusable LLM configurations so you never repeat setup code again.
- [LLM Registry](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Dynamically select and configure language models using the LLM registry.
- [LLM Streaming](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Stream LLM responses token-by-token for real-time display and interactive user experiences.
- [LLM Subscriptions](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Use your ChatGPT Plus/Pro subscription to access Codex models without consuming API credits.
- [Local Agent Server](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Install and run an Praxis Agent Server on your machine, then connect to it from the SDK.
- [Metrics Tracking](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Track token usage, costs, and latency metrics for your agents.
- [Model Context Protocol](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Model Context Protocol (MCP) enables dynamic tool integration from external servers. Agents can discover and use MCP-provided tools automatically.
- [Model Routing](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Route agent's LLM requests to different models.
- [Observability & Tracing](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Enable OpenTelemetry tracing to monitor and debug your agent's execution with tools like Laminar, MLflow, Honeycomb, or any OTLP-compatible backend.
- [OpenAI-Compatible Endpoint](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Call an Praxis agent-server through the OpenAI Chat Completions or Responses protocol.
- [self-hosted Praxis Workspace](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Connect to self-hosted Praxis for fully managed sandbox environments with optional SaaS credential inheritance.
- [Overview](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Run agents on remote servers with isolated workspaces for production deployments.
- [Parallel Tool Execution](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Execute multiple tools concurrently within a single LLM response to improve throughput for independent operations.
- [Pause and Resume](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Pause agent execution, perform operations, and resume without losing state.
- [Persistence](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Save and restore conversation state for multi-session workflows.
- [Persistent Memory](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Give agents opt-in, two-tier memory that survives across conversations.
- [Plugins](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Plugins bundle skills, hooks, MCP servers, agents, and commands into reusable packages that extend agent capabilities.
- [PR Review](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Use Praxis Agent to generate meaningful pull request review
- [Reasoning](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Access model reasoning traces from Anthropic extended thinking and OpenAI responses API.
- [Secret Registry](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Provide environment variables and secrets to agent workspace securely.
- [Security & Action Confirmation](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Control agent action execution through confirmation policy and security analyzer.
- [Send Message While Running](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Interrupt running agents to provide additional context or corrections.
- [Software Agent SDK](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Build AI agents that write software. A clean, modular SDK with production-ready tools.
- [Structured Output](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Attach a schema to any tool so the LLM returns typed, validated fields alongside the tool's own arguments.
- [Stuck Detector](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Detect and handle stuck agents automatically with timeout mechanisms.
- [Task Tool Set](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Delegate complex work to specialized sub-agents that run synchronously and return results to the parent agent.
- [Task-Based Model Routing](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Let the agent pick the best saved LLM profile for the task at hand with the built-in route_task_to_model tool.
- [Theory of Mind (TOM) Agent](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Enable your agent to understand user intent and preferences through Theory of Mind capabilities, providing personalized guidance based on user modeling.
- [TODO Management](https://github.com/Praxiss-Lab/Praxis/blob/main/docs/USER_GUIDE.md): Implement TODOs using Praxis Agent

## Examples

Source: [`examples/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples)

### [`01_standalone_sdk/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk)

- [`01_hello_world.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/01_hello_world.py)
- [`02_custom_tools.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/02_custom_tools.py)
- [`03_activate_skill.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/03_activate_skill.py)
- [`04_confirmation_mode_example.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/04_confirmation_mode_example.py)
- [`05_use_llm_registry.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/05_use_llm_registry.py)
- [`06_interactive_terminal_w_reasoning.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/06_interactive_terminal_w_reasoning.py)
- [`07_mcp_integration.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/07_mcp_integration.py)
- [`08_mcp_with_oauth.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/08_mcp_with_oauth.py)
- [`09_pause_example.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/09_pause_example.py)
- [`10_persistence.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/10_persistence.py)
- [`11_async.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/11_async.py)
- [`12_custom_secrets.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/12_custom_secrets.py)
- [`13_get_llm_metrics.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/13_get_llm_metrics.py)
- [`14_context_condenser.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/14_context_condenser.py)
- [`15_browser_use.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/15_browser_use.py)
- [`16_llm_security_analyzer.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/16_llm_security_analyzer.py)
- [`17_image_input.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/17_image_input.py)
- [`18_send_message_while_processing.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/18_send_message_while_processing.py)
- [`19_llm_routing.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/19_llm_routing.py)
- [`20_stuck_detector.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/20_stuck_detector.py)
- [`21_generate_extraneous_conversation_costs.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/21_generate_extraneous_conversation_costs.py)
- [`22_anthropic_thinking.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/22_anthropic_thinking.py)
- [`23_responses_reasoning.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/23_responses_reasoning.py)
- [`24_planning_agent_workflow.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/24_planning_agent_workflow.py)
- [`25_agent_delegation.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/25_agent_delegation.py)
- [`26_custom_visualizer.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/26_custom_visualizer.py)
- [`27_observability_laminar.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/27_observability_laminar.py)
- [`28_ask_agent_example.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/28_ask_agent_example.py)
- [`29_llm_streaming.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/29_llm_streaming.py)
- [`30_tom_agent.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/30_tom_agent.py)
- [`31_iterative_refinement.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/31_iterative_refinement.py)
- [`32_configurable_security_policy.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/32_configurable_security_policy.py)
- [`33_hooks`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk/33_hooks)
- [`34_critic_example.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/34_critic_example.py)
- [`35_subscription_login.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/35_subscription_login.py)
- [`36_event_json_to_openai_messages.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/36_event_json_to_openai_messages.py)
- [`37_llm_profile_store`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk/37_llm_profile_store)
- [`38_browser_session_recording.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/38_browser_session_recording.py)
- [`39_llm_fallback.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/39_llm_fallback.py)
- [`40_acp_agent_example.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/40_acp_agent_example.py)
- [`41_task_tool_set.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/41_task_tool_set.py)
- [`42_file_based_subagents.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/42_file_based_subagents.py)
- [`44_model_switching_in_convo.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/44_model_switching_in_convo.py)
- [`45_parallel_tool_execution.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/45_parallel_tool_execution.py)
- [`46_agent_settings.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/46_agent_settings.py)
- [`47_defense_in_depth_security.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/47_defense_in_depth_security.py)
- [`48_conversation_fork.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/48_conversation_fork.py)
- [`49_switch_llm_tool.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/49_switch_llm_tool.py)
- [`50_async_cancellation.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/50_async_cancellation.py)
- [`51_agent_hooks`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk/51_agent_hooks)
- [`52_dynamic_workflow.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/52_dynamic_workflow.py)
- [`53_client_defined_tools.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/53_client_defined_tools.py)
- [`54_goal_completion_loop.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/54_goal_completion_loop.py)
- [`55_persistent_memory.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/55_persistent_memory.py)
- [`56_structured_output.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/56_structured_output.py)
- [`57_prompt_hooks`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk/57_prompt_hooks)
- [`58_ask_oracle_tool`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/01_standalone_sdk/58_ask_oracle_tool)
- [`59_route_task_to_model.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/01_standalone_sdk/59_route_task_to_model.py)

### [`02_remote_agent_server/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/02_remote_agent_server)

- [`01_convo_with_local_agent_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/01_convo_with_local_agent_server.py)
- [`02_convo_with_docker_sandboxed_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/02_convo_with_docker_sandboxed_server.py)
- [`03_browser_use_with_docker_sandboxed_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/03_browser_use_with_docker_sandboxed_server.py)
- [`04_convo_with_api_sandboxed_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/04_convo_with_api_sandboxed_server.py)
- [`05_vscode_with_docker_sandboxed_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/05_vscode_with_docker_sandboxed_server.py)
- [`06_custom_tool`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/02_remote_agent_server/06_custom_tool)
- [`07_convo_with_cloud_workspace.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/07_convo_with_cloud_workspace.py)
- [`08_convo_with_apptainer_sandboxed_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/08_convo_with_apptainer_sandboxed_server.py)
- [`09_acp_agent_with_remote_runtime.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/09_acp_agent_with_remote_runtime.py)
- [`10_cloud_workspace_share_credentials.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/10_cloud_workspace_share_credentials.py)
- [`11_conversation_fork.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/11_conversation_fork.py)
- [`12_settings_and_secrets_api.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/12_settings_and_secrets_api.py)
- [`13_workspace_get_llm.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/13_workspace_get_llm.py)
- [`14_client_defined_tools.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/14_client_defined_tools.py)
- [`15_openai_compatible_gateway.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/15_openai_compatible_gateway.py)
- [`16_deferred_init.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/16_deferred_init.py)
- [`17_convo_with_agent_sandbox_server.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/02_remote_agent_server/17_convo_with_agent_sandbox_server.py)
- [`agent_sandbox_deploy`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/02_remote_agent_server/agent_sandbox_deploy)
- [`hook_scripts`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/02_remote_agent_server/hook_scripts)
- [`scripts`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/02_remote_agent_server/scripts)

### [`03_github_workflows/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows)

- [`01_basic_action`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows/01_basic_action)
- [`02_pr_review`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows/02_pr_review)
- [`03_todo_management`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows/03_todo_management)
- [`04_datadog_debugging`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows/04_datadog_debugging)
- [`05_posthog_debugging`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/03_github_workflows/05_posthog_debugging)

### [`04_llm_specific_tools/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/04_llm_specific_tools)

- [`01_gpt5_apply_patch_preset.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/04_llm_specific_tools/01_gpt5_apply_patch_preset.py)
- [`02_gemini_file_tools.py`](https://github.com/OpenHands/software-agent-sdk/blob/main/examples/04_llm_specific_tools/02_gemini_file_tools.py)

### [`05_skills_and_plugins/`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/05_skills_and_plugins)

- [`01_loading_agentskills`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/05_skills_and_plugins/01_loading_agentskills)
- [`02_loading_plugins`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/05_skills_and_plugins/02_loading_plugins)
- [`03_managing_installed_skills`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/05_skills_and_plugins/03_managing_installed_skills)
- [`04_mixed_marketplace_skills`](https://github.com/OpenHands/software-agent-sdk/tree/main/examples/05_skills_and_plugins/04_mixed_marketplace_skills)

