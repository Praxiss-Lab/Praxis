# Praxis Agent Server TypeScript client

This client belongs to [Praxis SDK](https://github.com/Praxiss-Lab/praxis-sdk) and is consumed by [Praxis](https://github.com/Praxiss-Lab/Praxis). The npm name `@openhands/typescript-client` remains a compatibility identifier. Build it from this repository rather than installing an upstream package release.

```sh
npm ci
npm run build
npm test
npm pack --ignore-scripts
```

Praxis installs a controlled archive of this build from its `vendor/` directory. No independent npm publication is assumed. Original licenses and author attribution remain preserved.

## Agent Server contract

The Python SDK owns the API implementation. Generate the client contract from this same checkout:

```sh
# From the repository root, after uv sync --dev --locked:
uv run python .github/scripts/export_agent_server_openapi.py --output /tmp/praxis-openapi.json
cd clients/typescript
AGENT_SERVER_OPENAPI_PATH=/tmp/praxis-openapi.json AGENT_SERVER_SCHEMA_SOURCE=Praxiss-Lab/praxis-sdk-source npm run generate:agent-server-api
AGENT_SERVER_OPENAPI_PATH=/tmp/praxis-openapi.json AGENT_SERVER_SCHEMA_SOURCE=Praxiss-Lab/praxis-sdk-source npm run check:agent-server-api
```

Active CI uses the current source contract. Optional release/image loading targets Praxiss-Lab and requires our own published artifacts. See [independent deployment](../../docs/independent-deployment.md).

## Quick Start

### Start an AgentServer

After building and publishing your own image, you will need an AgentServer running somewhere for the client to connect to. You can run one in docker:

```bash
docker run -p 127.0.0.1:8000:8000 -p 127.0.0.1:8001:8001 \
  -e SESSION_API_KEY="$SESSION_API_KEY" \
  -e OH_ALLOW_CORS_ORIGINS='["*"]' \
  ghcr.io/praxiss-lab/praxis-agent-server:1.54.0-python
```

### Creating a Conversation

```typescript
import { Conversation, Agent, Workspace } from '@openhands/typescript-client';

const agent = new Agent({
  llm: {
    model: 'gpt-4',
    api_key: 'your-openai-api-key',
  },
});

// Create a remote workspace
const workspace = new Workspace({
  host: 'http://localhost:3000',
  workingDir: '/tmp',
  apiKey: 'your-session-api-key',
});

const conversation = new Conversation(agent, workspace, {
  callback: (event) => {
    console.log('Received event:', event);
  },
});

// Start the conversation with an initial message
await conversation.start({
  initialMessage: 'Hello, can you help me write some code?',
});

// Start WebSocket for real-time events
await conversation.startWebSocketClient();

// Send a message and run the agent
await conversation.sendMessage('Create a simple Python script that prints "Hello World"');
await conversation.run();
```

### Loading an Existing Conversation

```typescript
// Create a remote workspace for the existing conversation
const workspace = new Workspace({
  host: 'http://localhost:3000',
  workingDir: '/tmp',
  apiKey: 'your-session-api-key',
});

const conversation = new Conversation(agent, workspace, {
  conversationId: 'conversation-id-here',
});

// Connect to the existing conversation
await conversation.start();
```

### Using the Workspace

```typescript
// Execute commands
const result = await conversation.workspace.executeCommand('ls -la');
console.log('Command output:', result.stdout);
console.log('Exit code:', result.exit_code);

// Access lower-level bash APIs from the workspace
const bashCommand = await conversation.workspace.bash.startCommand('ls -la');
const bashEvents = await conversation.workspace.bash.searchEvents({
  command_id__eq: bashCommand.id,
  limit: 20,
});

// Upload a file
const uploadResult = await conversation.workspace.fileUpload(
  './local-file.txt',
  '/remote/path/file.txt'
);

// Download a file
const downloadResult = await conversation.workspace.fileDownload(
  '/remote/path/file.txt',
  './downloaded-file.txt'
);
```

### Server-wide Operations

```typescript
import { ConversationManager } from '@openhands/typescript-client';

const manager = new ConversationManager({
  host: 'http://localhost:3000',
  apiKey: 'your-session-api-key',
});

const serverInfo = await manager.server.getServerInfo();
const providers = await manager.llm.getProviders();
const tools = await manager.tools.listTools();
const acpCount = await manager.acp.countConversations();
```

### Updating MCP settings

Persisted MCP servers use their settings-map key as stable identity. Create,
update, or delete one server without fetching and resending the whole catalog:

```typescript
const settings = manager.settings;

await settings.createMcpServer('github', {
  transport: 'http',
  url: 'https://example.test/mcp',
});

await settings.patchMcpServer('github', {
  url: 'https://example.test/mcp/v2',
});

await settings.deleteMcpServer('old-server');
```

An omitted patch field preserves its stored value, including credentials.
Supplying a value replaces it, and `null` explicitly clears a supported
optional field or deletes a map entry. Each helper sends one
request to the corresponding Agent Server MCP settings operation.

If you need the lower-level endpoint-specific clients directly, import them from the secondary entrypoint:

```typescript
import { ServerClient, BashClient } from '@openhands/typescript-client/clients';
```

### Aggregate Agent Server and Cloud Clients

The `/clients` entrypoint also exposes aggregate clients. `AgentServerClient` bundles every agent-server endpoint client behind namespaces, and `CloudClient` covers the OpenHands Cloud app API (bearer auth, org scoping, and an optional proxy for runtime-sandbox calls):

```typescript
import { AgentServerClient, CloudClient } from '@openhands/typescript-client/clients';

const agentServer = new AgentServerClient({
  host: 'http://localhost:3000',
  apiKey: 'your-session-api-key',
});
const health = await agentServer.server.getHealth();
const conversations = await agentServer.conversations.searchConversations();

const cloud = new CloudClient({
  host: 'https://app.all-hands.dev',
  apiKey: 'your-cloud-api-key',
  orgId: 'optional-org-id', // sent as X-Org-Id on every request
  // Optional: requests with `hostOverride` (runtime-sandbox calls) are
  // routed through this agent-server's /api/cloud-proxy endpoint instead
  // of being sent to the host directly.
  proxy: { host: 'http://localhost:3000', apiKey: 'your-session-api-key' },
});
const orgs = await cloud.getOrganizations();
const created = await cloud.createConversation({ initial_message: 'Fix the bug' });
```

To obtain a Cloud API key interactively, use the device-flow helpers:

```typescript
import { startDeviceFlow, pollForToken } from '@openhands/typescript-client/clients';

const requestMetadata = {
  headers: { 'X-My-Client': 'my-client-name' },
};
const auth = await startDeviceFlow('https://app.all-hands.dev', requestMetadata);
console.log(`Approve this device at ${auth.verification_uri_complete}`);
const token = await pollForToken('https://app.all-hands.dev', auth.device_code, {
  interval: auth.interval,
  ...requestMetadata,
});
const cloud = new CloudClient({
  host: 'https://app.all-hands.dev',
  apiKey: token.access_token,
});
```

### Working with Events

```typescript
// Access the events list
const events = await conversation.state.events.getEvents();
console.log(`Total events: ${events.length}`);

// Iterate through events
for await (const event of conversation.state.events) {
  console.log(`Event: ${event.kind} at ${event.timestamp}`);
}
```

### Managing Conversation State

```typescript
// Get conversation status
const status = await conversation.state.getAgentStatus();
console.log('Agent status:', status);

// Get conversation stats
const stats = await conversation.conversationStats();
console.log('Total events:', stats.total_events);

// Set confirmation policy
await conversation.setConfirmationPolicy({ type: 'always' });

// Update secrets
await conversation.updateSecrets({
  API_KEY: 'secret-value',
  DATABASE_URL: () => process.env.DATABASE_URL || 'default-url',
});
```

## API Reference

### Conversation

Factory function that creates conversations with Praxis agents.

#### Constructor

- `new Conversation(agent, workspace, options?)` - Create a new conversation instance

#### Instance Methods

- `start(options?)` - Start the conversation (creates new or connects to existing)

- `sendMessage(message)` - Send a message to the agent
- `run()` - Start agent execution
- `pause()` - Pause agent execution
- `setConfirmationPolicy(policy)` - Set confirmation policy
- `sendConfirmationResponse(accept, reason?)` - Respond to confirmation requests
- `updateSecrets(secrets)` - Update conversation secrets
- `startWebSocketClient()` - Start real-time event streaming
- `stopWebSocketClient()` - Stop real-time event streaming
- `conversationStats()` - Get conversation statistics
- `close()` - Clean up resources

#### Properties

- `id` - Conversation ID
- `state` - RemoteState instance for accessing conversation state
- `workspace` - RemoteWorkspace instance for command execution and file operations

### RemoteWorkspace

Handles remote command execution and file operations.

#### Methods

- `executeCommand(command, cwd?, timeout?)` - Execute a bash command
- `fileUpload(sourcePath, destinationPath)` - Upload a file
- `fileDownload(sourcePath, destinationPath)` - Download a file
- `gitChanges(path)` - Get git changes for a path
- `gitDiff(path)` - Get git diff for a path
- `close()` - Clean up resources

### RemoteState

Manages conversation state and provides access to events.

#### Properties

- `id` - Conversation ID
- `events` - RemoteEventsList instance

#### Methods

- `getAgentStatus()` - Get current agent execution status
- `getConfirmationPolicy()` - Get current confirmation policy
- `getActivatedKnowledgeSkills()` - Get activated knowledge skills
- `getAgent()` - Get agent configuration
- `getWorkspace()` - Get workspace configuration
- `getPersistenceDir()` - Get persistence directory
- `modelDump()` - Get state as plain object
- `modelDumpJson()` - Get state as JSON string

### RemoteEventsList

Manages conversation events with caching and synchronization.

#### Methods

- `addEvent(event)` - Add an event to the cache
- `length()` - Get number of cached events
- `getEvent(index)` - Get event by index
- `getEvents(start?, end?)` - Get events slice
- `createDefaultCallback()` - Create a default event callback

### WebSocketCallbackClient

Handles real-time event streaming via WebSocket.

#### Methods

- `start()` - Start WebSocket connection
- `stop()` - Stop WebSocket connection

## Types

The library includes comprehensive TypeScript type definitions:

- `ConversationID` - Conversation identifier type
- `Event` - Base event interface
- `Message` - Message interface with content
- `AgentBase` - Agent configuration interface
- `CommandResult` - Command execution result
- `FileOperationResult` - File operation result
- `ConversationStats` - Conversation statistics
- `AgentExecutionStatus` - Agent status enum
- And many more...

## Error Handling

When the server answers with an error status, the client throws an `HttpError`:

```typescript
import { isHttpError } from '@openhands/typescript-client';

try {
  await conversation.sendMessage('Hello');
} catch (error) {
  if (isHttpError(error)) {
    console.error(`HTTP Error ${error.status}: ${error.statusText}`);
    // The server's own message, e.g. "Profile 'missing' not found".
    console.error('Detail:', error.detail ?? 'none');
    console.error('Response:', error.response);
  } else {
    console.error('Unexpected error:', error);
  }
}
```

- `status`, `statusText`: the HTTP status.
- `response`: the error body: parsed JSON when the server sent JSON, otherwise the text, or
  `null` when the body could not be read.
- `message`: transport text for logs, `HTTP request failed (<status> <text>): <body>`.
- `detail`: the server's readable message, or `undefined` when the body has none:
  - `{"detail": "..."}` gives the string.
  - A validation error body (`{"detail": [{"loc", "msg", "type"}, ...]}`, usually a 422)
    gives the `msg` of a single entry. Several entries are joined with `"; "`, each
    prefixed with its field name (the last string in `loc`), e.g.
    `name: Field required; model: Field required`.
  - `{"detail": {"message": "...", ...}}` gives the `message`.
  - Any other body, such as a proxy's HTML error page, gives `undefined`.
- `validationErrors`: the `{ loc, msg, type }` entries of a validation error body, or
  `undefined`. Use it to point each message at its form field.

`isHttpError(error)` also recognizes an `HttpError` thrown by another copy of this package
(for example when an app and a library each bundle their own), where
`error instanceof HttpError` is false, as long as that copy is a version that
includes `isHttpError` (older copies do not brand their errors). `instanceof` still
works within one copy.

## Development

### Building

```bash
npm run build
```

### Development Mode

```bash
npm run dev
```

### Linting

```bash
npm run lint
```

### Formatting

```bash
npm run format
```

## Testing

### Unit Tests

Run unit tests (no external dependencies required):

```bash
npm test
```

### Integration Tests

Integration tests require a running agent-server in Docker with a mounted workspace. These tests verify the full functionality against a real server.

#### Prerequisites

1. Docker installed and running
2. LLM API key (e.g., Anthropic or OpenAI)

#### Running Integration Tests Locally

1. Create a workspace directory:

   ```bash
   mkdir -p /tmp/agent-workspace
   chmod 777 /tmp/agent-workspace
   ```

2. Start the agent-server container (software-agent-sdk v1.44.0):

   ```bash
   docker run -d \
     --name agent-server \
     -p 127.0.0.1:8010:8000 \
     -v /tmp/agent-workspace:/workspace \
     ghcr.io/openhands/agent-server:1.44.0-python --host 0.0.0.0
   ```

3. Wait for the server to be ready:

   ```bash
   # Check server health
   curl http://localhost:8010/health
   ```

4. Run integration tests:

   ```bash
   export LLM_API_KEY="your-api-key"
   export LLM_MODEL="anthropic/claude-sonnet-4-5-20250929"
   npm run test:integration
   ```

5. Cleanup:
   ```bash
   docker stop agent-server && docker rm agent-server
   ```

#### Environment Variables

| Variable              | Required | Default                 | Description                                                   |
| --------------------- | -------- | ----------------------- | ------------------------------------------------------------- |
| `LLM_API_KEY`         | Yes      | -                       | API key for the LLM provider                                  |
| `LLM_MODEL`           | Yes      | -                       | LLM model name (e.g., `anthropic/claude-sonnet-4-5-20250929`) |
| `LLM_BASE_URL`        | No       | -                       | Custom base URL for LLM API                                   |
| `AGENT_SERVER_URL`    | No       | `http://localhost:8010` | URL of the agent server                                       |
| `HOST_WORKSPACE_DIR`  | No       | `/tmp/agent-workspace`  | Path to workspace on host                                     |
| `AGENT_WORKSPACE_DIR` | No       | `/workspace`            | Path to workspace inside container                            |
| `TEST_TIMEOUT`        | No       | `120000`                | Test timeout in milliseconds                                  |

#### Integration Test Coverage

The integration tests cover:

- **Workspace Operations**: Command execution, file upload/download, round-trip operations
- **Conversation Lifecycle**: Creation, message sending, running agents, pausing
- **Event Streaming**: WebSocket connections, event callbacks, different event types
- **HTTP Client**: Health checks, GET/POST requests, error handling
- **End-to-End Tasks**: File creation/modification/deletion via agent, multi-step tasks

#### CI/CD

Integration tests run automatically in GitHub Actions when:

- Pushing to `main` or `develop` branches
- Opening pull requests to these branches
- Manually triggering the workflow

The workflow requires the following secrets:

- `LLM_API_KEY`: API key for the LLM provider
- `LLM_MODEL` (optional): Override the default model

### Running All Tests

```bash
npm run test:all
```

## License

MIT

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Browser conversation event streams

`ConversationEventStream` from `@openhands/typescript-client/clients` owns the
Agent Server event socket transport. Use it when an application already manages
conversation state and needs raw event frames and connection lifecycle callbacks.
It authenticates with the first frame, preserves replay parameters, reconnects
with exponential backoff and jitter when enabled, and aborts stalled handshakes
after 10 seconds. It does not retain message history.

```typescript
import {
  ConversationEventStream,
  buildConversationEventStreamUrl,
} from '@openhands/typescript-client/clients';

const stream = new ConversationEventStream({
  url: buildConversationEventStreamUrl(agentServerUrl, conversationId),
  sessionApiKey,
  queryParams: { resend_mode: 'all' },
  reconnect: { enabled: true },
  onMessage: (frame) => handleEvent(JSON.parse(frame.data)),
  onStateChange: (state) => renderConnectionState(state),
});
stream.start();
// When the stream is open:
stream.send(JSON.stringify({ role: 'user', content: [{ type: 'text', text: 'Hello' }], run: true }));
// When the owner is disposed:
stream.stop();
```

`updateOptions` refreshes callbacks and credentials without reconnecting; new
credentials take effect on the next handshake. `reconnect()` replaces the active
socket and resets the retry budget. `send()` throws while disconnected, allowing
the application to use `ConversationClient.sendEvent` as a REST fallback.
The client requires a Web-standard global `WebSocket` only when started and has
no Node-specific imports. Pass credentials through `sessionApiKey`; credentials
in the socket URL or query parameters are rejected.
